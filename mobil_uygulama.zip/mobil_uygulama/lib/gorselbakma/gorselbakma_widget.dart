import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';

class GorselbakmaWidget extends StatefulWidget {
  const GorselbakmaWidget({
    Key key,
    this.gorsel,
  }) : super(key: key);

  final String gorsel;

  @override
  _GorselbakmaWidgetState createState() => _GorselbakmaWidgetState();
}

class _GorselbakmaWidgetState extends State<GorselbakmaWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: Color(0xFFF5F5F5),
      body: SafeArea(
        child: CachedNetworkImage(
          imageUrl: widget.gorsel,
          width: double.infinity,
          height: double.infinity,
          fit: BoxFit.contain,
        ),
      ),
    );
  }
}
